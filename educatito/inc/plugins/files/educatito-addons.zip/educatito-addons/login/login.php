<?php
if (!function_exists('educatito_form_login')):

    function educatito_form_login() {
        ?>
        <div class="cd-user-modal"> 
            <div class="cd-user-modal-container"> 
                <ul class="cd-switcher">
                    <li><a href="javascript:void(0)"><?php echo esc_html__("Login") ?></a></li>
                    <li><a href="javascript:void(0)"><?php echo esc_html__("Register") ?></a></li>
                </ul>
                <div id="cd-login"> 
                    <form class="cd-form" id="login" action="login" method="post">
                        <div class="logo-form">
                            <img src="<?php echo EDUCATITO_PLUGIN_URL ?>images/logo.png" alt="logo-form" >
                        </div>
                        <p class="status"></p>
                        <p class="fieldset">
                            <input class="full-width has-padding has-border" name="username" id="username" type="text" placeholder="<?php echo esc_attr__('Username', 'educatito') ?>">
                        </p>

                        <p class="fieldset">
                            <input class="full-width has-padding has-border" name="password" id="password" type="password"  placeholder="<?php echo esc_attr__('Password', 'educatito') ?>">
                            <a href="javascript:void(0)" class="hide-password"><?php echo esc_html__('Show', 'educatito') ?></a>
                        </p>
                        <p class="fieldset">
                            <input type="checkbox" id="remember-me">
                            <label for="remember-me"><?php echo esc_html__('Remember me', 'educatito') ?></label>
                        </p>
                        <p class="fieldset">
                            <input class="full-width" type="submit" value="<?php echo esc_attr__('Login', 'educatito') ?>">
                            <?php wp_nonce_field('ajax-login-nonce', 'security'); ?>
                        </p>
                    </form>
                </div> 

                <div id="cd-signup">
                    <form class="cd-form" id="register" action="register" method="post">
                        <div class="logo-form">
                            <img src="<?php echo EDUCATITO_PLUGIN_URL ?>images/logo.png" alt="logo-form" >
                        </div>
                        <p class="status"></p>
                        <p class="fieldset">
                            <input class="full-width has-padding has-border" id="signup-username" type="text" placeholder="<?php echo esc_attr__('Username', 'educatito') ?>">
                        </p>

                        <p class="fieldset">
                            <input class="full-width has-padding has-border" id="signup-email" type="email" placeholder="<?php echo esc_attr__('E-mail', 'educatito') ?>">
                        </p>

                        <p class="fieldset">
                            <input class="full-width has-padding has-border" id="signup-password" type="password"  placeholder="<?php echo esc_attr__('Password', 'educatito') ?>">
                        </p>

                        <p class="fieldset">
                            <input class="full-width has-padding has-border" id="signup-password-confirm" type="password"  placeholder="<?php echo esc_attr__('Confirm Password', 'educatito') ?>">
                        </p>

                        <p class="fieldset">
                            <input class="full-width has-padding" type="submit" value="<?php echo esc_attr__('Create Account', 'educatito') ?>">
                            <?php wp_nonce_field('ajax-register-nonce', 'security-register', true, true); ?>
                        </p>
                    </form>
                </div>
                <a href="javascript:void(0)" class="cd-close-form"></a>
            </div> 
        </div>
        <?php
    }

endif;

add_action('init', 'ajax_login_init');

function ajax_login_init() {
    wp_register_script('ajax-login-script', get_template_directory_uri() . '/assets/js/ajax-login-script.js', array('jquery'));
    wp_enqueue_script('ajax-login-script');
    wp_localize_script('ajax-login-script', 'ajax_login_object', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'redirecturl' => home_url(),
        'loadingmessage' => __('Sending user info, please wait...')
    ));
    wp_localize_script('ajax-login-script', 'ajax_register_object', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'redirecturl' => home_url(),
        'loadingmessage' => __('Sending , please wait...')
    ));
    add_action('wp_ajax_nopriv_ajaxlogin', 'ajax_login');
    add_action('wp_ajax_ajaxregister', 'ajax_register');
    add_action('wp_ajax_nopriv_ajaxregister', 'ajax_register');
}

function ajax_login() {
    check_ajax_referer('ajax-login-nonce', 'security');
    $info = array();
    $info['user_login'] = $_POST['username'];
    $info['user_password'] = $_POST['password'];
    if ($_POST['remember'] != 0) {
        $info['remember'] = true;
    } else {
        $info['remember'] = false;
    }
    $user_signon = wp_signon($info, false);
    if (is_wp_error($user_signon)) {
        echo json_encode(array('loggedin' => false, 'message' => esc_html__('Wrong username or password.')));
    } else {
        wp_set_current_user($user_signon->ID);
        wp_set_auth_cookie($user_signon->ID);
        echo json_encode(array('loggedin' => true, 'message' => esc_html__('Login successful, redirecting...')));
    }
    die();
}

function ajax_register() {
    check_ajax_referer('ajax-register-nonce', 'security');
    $username = $_POST['username'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $email = $_POST['email'];
    $home_url = home_url();
    if ($password != $cpassword) {
        echo json_encode(array('register' => false, 'message' => esc_html__('Incorrect password...')));
    } else {
        $userdata = array(
            'user_login' => $username,
            'user_pass' => $password,
            'user_email' => $email,
        );

        $user_id = wp_insert_user($userdata);

        if (is_wp_error($user_id)) {
            echo json_encode(array('register' => false, 'message' => $user_id->get_error_message()));
        } else {
            $subject = "Educatito";
            $message = "You have successfully registered your account\n Username: $username\n Email: $email\n Password: $password\n Click in here $home_url to login to website\n";
            $headers = 'From: ' . $username . ' <' . $email . '>' . "\r\n";
            $test = wp_mail($email, $subject, $message, $headers);
            $info = array();
            $info['user_login'] = $username;
            $info['user_password'] = $password;
            $info['remember'] = true;
            $user_signon = wp_signon($info, false);
            if (is_wp_error($user_signon)) {
                echo json_encode(array('register' => false, 'message' => esc_html__('Register Error')));
            } else {
                wp_set_current_user($user_signon->ID);
                wp_set_auth_cookie($user_signon->ID);
                echo json_encode(array('register' => true, 'message' => esc_html__('Register Successful, redirecting...')));
            }
        }
    }
    die();
}
